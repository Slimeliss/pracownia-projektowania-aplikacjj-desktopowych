import ShoppingItem from "./ShoppingItem.js";

const nameInput: HTMLButtonElement|null = document.querySelector("#todoAddButton");
const inputTextField: HTMLInputElement|null = document.querySelector("#todoInputField") ;
const todosContainer: HTMLDivElement = document.querySelector("#todoContainer")!;

let arrayOfTodos: ShoppingItem[] = [];

if (addButton && inputTextField && todosContainer){
    
    addButton?.addEventListener('click',(e) =>{
        
        arrayOfTodos.push(new TodoEntry(arrayOfTodos.length, inputTextField?.value));
        inputTextField.value='';
        buildList();
    })
}