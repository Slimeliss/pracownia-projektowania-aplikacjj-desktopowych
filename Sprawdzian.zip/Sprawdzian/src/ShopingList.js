ItemFilter - "all" || "toBuy" ||
    class ShoppingList {
        items;
        nextId;
        constructor(items) {
            this.items = items;
        }
    };
export {};
