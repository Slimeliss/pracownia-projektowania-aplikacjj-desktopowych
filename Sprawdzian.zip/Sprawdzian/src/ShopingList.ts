import ShoppingItem from "./ShoppingItem.js"

ItemFilter - "all" || "toBuy" ||

class ShoppingList{
    items: ShoppingItem[];
    nextId: Number;

    constructor(items: ShoppingItem[]) {
        this.items = items;
    }
}