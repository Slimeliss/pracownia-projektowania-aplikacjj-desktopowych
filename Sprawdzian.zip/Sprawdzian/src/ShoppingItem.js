"use strict";
class ShoppingItem {
    id;
    name;
    quantity;
    isBought;
    constructor(id, name, quantity, isBought = false) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.isBought = isBought;
    }
}
toogle();
void {
    this: .isBought != this.isBought,
};
render();
HTMLElement;
{
    const item = document.createElement("div");
    item.className = "item";
    if (this.isBought) {
        item.classList.add('bought');
    }
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = this.name;
    const qtyElem = document.createElement("span");
    qtyElem.className = "quantity";
    qtyElem.textContent = `x${this.quantity}`;
}
